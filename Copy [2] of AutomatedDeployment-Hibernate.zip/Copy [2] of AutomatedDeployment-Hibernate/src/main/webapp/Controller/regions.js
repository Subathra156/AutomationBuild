/**
 * 
 * Controller to fetch the availabble regions into the drop down
 * @since:08/17/2017
 * 
 */
app.controller("regionsController", function($scope, view, $cookieStore) {
	$scope.disableBtn = true;
	var isChecked = false;

	view.fetchRegions().then(function(response) {
		$scope.myData = response.data;
		console.log(myData.regionId);

	});

	/*
	 * Replace the contents in the xml Date: 08/18/2017
	 */

	$scope.Options = [ 'Build Online Interface', 'Build BWI_WEB', 'Build ACL',
			'Build FX Monitor', 'Build MM Monitor', 'Build Futures Monitor',
			'Build Syscon' ];
	$scope.select = {
		Options : [ 'Build Online Interface' ]
	};

	$scope.Checks = [ 'All', 'CNJ', 'TPC'

	];
	$scope.selected = {
		Checks : [ 'All' ]
	};

	/*Get details on clicking start button*/

	$scope.showStart = function(regionId, region2, username, pswd) {

		$cookieStore.put("regionCookie", regionId);
		var regionName = $cookieStore.get("regionCookie");
		var checkedBoxes = "";
		var SelectedOptions = "";
		for (var i = 0; i < $scope.selected.Checks.length; i++) {
			checkedBoxes += $scope.selected.Checks[i] + " ";
		}
		for (var j = 0; j < $scope.select.Options.length; j++) {
			SelectedOptions += $scope.select.Options[j] + " ";
		}
		view.getStartButton(checkedBoxes, SelectedOptions, regionName, region2,
				username, pswd).then(function(response) {

			$scope.checked = response.data;

		});

		alert(checkedBoxes, regionName);

	};

	/*
	 * Get details on clicking stop button
	 * */
	
	$scope.showStop = function(regionId, region2, username, pswd) {
		$cookieStore.put("regionCookie", regionId);
		var regionName = $cookieStore.get("regionCookie");
		var checkedBoxes = "";
		var SelectedOptions = "";
		for (var i = 0; i < $scope.selected.Checks.length; i++) {
			checkedBoxes += $scope.selected.Checks[i] + " ";
		}
		for (var j = 0; j < $scope.select.Options.length; j++) {
			SelectedOptions += $scope.select.Options[j] + " ";
		}
		view.getStopButton(checkedBoxes, SelectedOptions, regionName, region2,
				username, pswd).then(function(response) {

			$scope.checked = response.data;

		});

		alert(checkedBoxes, regionName);

	};

	/*
	 * Get details on clicking  Restart button
	 * */
	$scope.showRestart = function(regionId, region2, username, pswd) {
		$cookieStore.put("regionCookie", regionId);
		var regionName = $cookieStore.get("regionCookie");
		var checkedBoxes = "";
		var SelectedOptions = "";
		for (var i = 0; i < $scope.selected.Checks.length; i++) {
			checkedBoxes += $scope.selected.Checks[i] + " ";
		}
		for (var j = 0; j < $scope.select.Options.length; j++) {
			SelectedOptions += $scope.select.Options[j] + " ";
		}
		view.getRestartButton(checkedBoxes, SelectedOptions, regionName,
				region2, username, pswd).then(function(response) {

			$scope.checked = response.data;

		});

		alert(checkedBoxes, regionName);

	};

	/*
	 * Get details on clicking Deploy button
	 * */
	$scope.replaceXml = function(region, region2, username, pswd) {
		$cookieStore.put("regionCookie", region);
		var regionName = $cookieStore.get("regionCookie");
		console.log(regionName);
		var checkedBoxes = "";
		var SelectedOptions = "";
		for (var i = 0; i < $scope.selected.Checks.length; i++) {
			checkedBoxes += $scope.selected.Checks[i] + " ";
		}
		for (var j = 0; j < $scope.select.Options.length; j++) {
			SelectedOptions += $scope.select.Options[j] + " ";
		}

		view.replaceRegions(regionName, checkedBoxes, SelectedOptions, region2,
				username, pswd).then(function(response) {
			console.log(regionName);
			$scope.xmlData = response.data;

		});

	};

	$scope.getCheckBoxes = function(name) {
		$scope.CheckBoxes = [];
		$scope.CheckBoxes.push(name);
		console.log($scope.CheckBoxes);
		view.selectedCheckBoxes(name);
	};

});
