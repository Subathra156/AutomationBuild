/**
 * 
 * Ajax call to fetch the regions through the API call Date:08/17/2017
 */

app.factory("view", [
		'$http',
		function($http) {
			return {
				fetchRegions : function() {

					return $http.get("../regions");
				},
				/*
				 * Ajax call to replace selected region through the API call
				 * Date:08/18/2017
				 */
				replaceRegions : function(regionName, checkedBoxes,
						SelectedOptions, region2, username, pswd) {

					return $http.get("../regions/" + regionName + "/"
							+ checkedBoxes + "/" + SelectedOptions + "/"
							+ region2 + "/" + username + "/" + pswd);
				},

				/*
				 * Ajax call to get the Selected CheckBoxes via the API call
				 * Date:09/28/2017
				 */
				selectedCheckBoxes : function(name) {
					return $http.get("../checks/" + name);
				},

				/*
				 * Ajax call to the details on clicking the various buttons
				 * Date:09/30/2017
				 */
				getStartButton : function(checkedBoxes, SelectedOptions,
						regionName, region2, username, pswd) {

					return $http.get("../buttonStart/" + regionName + "/"
							+ checkedBoxes + "/" + SelectedOptions + "/"
							+ region2 + "/" + username + "/" + pswd);
					alert(details);
				},

				getStopButton : function(checkedBoxes, SelectedOptions,
						regionName, region2, username, pswd) {
					return $http.get("../buttonStop/" + regionName + "/"
							+ checkedBoxes + "/" + SelectedOptions + "/"
							+ region2 + "/" + username + "/" + pswd);
				},

				getRestartButton : function(checkedBoxes, SelectedOptions,
						regionName, region2, username, pswd) {
					return $http.get("../buttonRestart/" + regionName + "/"
							+ checkedBoxes + "/" + SelectedOptions + "/"
							+ region2 + "/" + username + "/" + pswd);
				}

			}
		} ]);