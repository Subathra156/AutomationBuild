/**
 * Module name specification
 */

var app = angular.module("myApp", [ 'ngCookies' ,'checklist-model' ]);