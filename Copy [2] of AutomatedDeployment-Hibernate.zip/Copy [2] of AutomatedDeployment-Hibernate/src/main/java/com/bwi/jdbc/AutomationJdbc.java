package com.bwi.jdbc;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.sql.DataSource;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import springfox.documentation.spring.web.json.Json;

import com.bwi.bean.RegionProperties;
import com.bwi.mapper.RegionMapper;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.databind.util.JSONPObject;

import com.sample.hibernate.Deployment;
import com.sample.hibernate.DeploymentHandle;

/**
 * @author XBBNHD2 Desc:JDBC Class for all service implementations
 */

@Transactional
public class AutomationJdbc {
	List<String> regionList = new ArrayList<String>();
	List<String> regionListTemp = new ArrayList<String>();
	private static final String FILENAME = "H://xml.txt";
	String newtext;
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;

	/**
	 * @param dataSource
	 *            Desc:Set the database properties from the xml file
	 */
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	}

	/**
	 * @return regionList Desc:Business logic to retrieve db data to be
	 *         populated into the drop down
	 */
	/*public List<String> populateRegionDropDown() {
		
		 * try { String Sql = "SELECT * FROM deployment_region";
		 * 
		 * regionList = jdbcTemplateObject.query(Sql, new Object[] {}, new
		 * RegionMapper()); System.out.println(regionList); return regionList; }
		 * catch (Exception e) { return null; }
		 

		DeploymentHandle dh = new DeploymentHandle();
		List<Deployment> deployment = new ArrayList<Deployment>();
		List<String> regionList1 = new ArrayList<String>();
		
		deployment.addAll(dh.getAll());
		Iterator itr = deployment.iterator();
		while (itr.hasNext()) {
			Deployment db = (Deployment) itr.next();
			regionList1.add(db.getRegion());

		}
		System.out.println(regionList);
		return regionList1;

	}
*/
	/**
	 * Desc: Business logic to read the xml file from the local and replace the
	 * selected regions in the file that is read
	 * 
	 * @since 08/18/2017
	 * @param regionName
	 * @return Xml text
	 */
	public String replaceRegion(String regionName) {

		JSONObject obj = new JSONObject();

		try {
			FileReader fr = new FileReader(FILENAME);
			BufferedReader reader = new BufferedReader(fr);
			String line = "", oldtext = "";
			while ((line = reader.readLine()) != null) {
				oldtext += line + "\r\n";

			}

			reader.close();

			newtext = oldtext.replaceAll("dev06", regionName.toLowerCase());
			obj.put("xml", newtext);

			FileWriter writer = new FileWriter("H://xmlReplaced.txt");
			writer.write(newtext);
			writer.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}

		return obj.toJSONString();
	}

	/**
	 * Desc: Returns json array read from external file
	 * 
	 * @since 09/29/2017
	 * @return jsonArray
	 * @throws IOException
	 * @throws ParseException
	 */
	public JSONArray populateDropDown() throws IOException, ParseException {

		JSONParser parser = new JSONParser();

		Object obj = parser.parse(new FileReader("C:/Data/Sample/region.json"));

		JSONArray jsonObject = (JSONArray) obj;

		return jsonObject;

	}
}
