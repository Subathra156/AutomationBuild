package com.bwi.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bwi.jdbc.AutomationJdbc;
import com.sample.hibernate.Deployment;
import com.sample.hibernate.DeploymentHandle;

/**
 * Description:Controller class with Rest API calls to Autopopulate the dropdown
 * with the available regions
 * 
 * @author XBBNHD2
 *
 */
@RestController
public class AutomationController {
	@Autowired
	DeploymentHandle dh;
	private static final Logger logger = LogManager
			.getLogger(AutomationController.class);

	AutomationJdbc automationJdbc = new AutomationJdbc();

	JSONArray regionListJson = new JSONArray();
	List<String> regionList = new ArrayList<String>();

	/**
	 * Desc:API to fetch the regions from the database and populate the dropdown
	 * list of regions Date:08/17/2017
	 * 
	 * @return regionList
	 */
	@RequestMapping(value = "/regions", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<String> populateRegionDropDown() {

		List<Deployment> deployment = new ArrayList<Deployment>();
		List<String> regionList1 = new ArrayList<String>();

		deployment.addAll(dh.getAll());
		Iterator itr = deployment.iterator();
		while (itr.hasNext()) {
			Deployment db = (Deployment) itr.next();
			regionList1.add(db.getRegion());

		}
		
		return regionList1;

	}

	/**
	 * Desc:API to replace the selected region in the xml script, to be replaced
	 * in the pom.xml Date:08/21/2017
	 * 
	 * @param selectedCheckBox
	 * @param regionName
	 * @param selectedOptions
	 * @param region2
	 * @param username
	 * @param pswd
	 * @return
	 */
	@RequestMapping(value = "/regions/{regionName}/{selectedCheckBox}/{selectedOptions}/{region2}/{username}/{pswd}", method = RequestMethod.GET)
	public String replaceRegion(
			@PathVariable("selectedCheckBox") String selectedCheckBox,
			@PathVariable("regionName") String regionName,
			@PathVariable("selectedOptions") String selectedOptions,
			@PathVariable("region2") String region2,
			@PathVariable("username") String username,
			@PathVariable("pswd") String pswd) {
		String replaced = automationJdbc.replaceRegion(regionName);
		logger.info("Deploy" + " " + selectedCheckBox + " " + regionName);
		logger.info(region2 + " " + selectedOptions + " " + username + " "
				+ pswd);

		return replaced;
	}

	/**
	 * Desc:Reads json from external file and returns json array
	 * 
	 * @return jsonArray
	 * @throws IOException
	 * @throws ParseException
	 */
	@RequestMapping(value = "/jsons", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public JSONArray populateDropDown() throws IOException, ParseException {
		regionListJson = automationJdbc.populateDropDown();

		return regionListJson;
	}

	/**
	 * Desc: get details on clicking the Start button
	 * 
	 * @param selectedCheckBox
	 * @param regionName
	 * @param selectedOptions
	 * @param region2
	 * @param username
	 * @param pswd
	 */
	@RequestMapping(value = "/buttonStart/{regionName}/{selectedCheckBox}/{selectedOptions}/{region2}/{username}/{pswd}", method = RequestMethod.GET)
	public void logStartCheckBoxes(
			@PathVariable("selectedCheckBox") String selectedCheckBox,
			@PathVariable("regionName") String regionName,
			@PathVariable("selectedOptions") String selectedOptions,
			@PathVariable("region2") String region2,
			@PathVariable("username") String username,
			@PathVariable("pswd") String pswd) {

		logger.info("Start" + " " + selectedCheckBox + " " + regionName);
		logger.info(region2 + " " + selectedOptions + " " + username + " "
				+ pswd);

	}

	/**
	 * Desc: get details on clicking the Stop button
	 * 
	 * @param selectedCheckBox
	 * @param regionName
	 * @param selectedOptions
	 * @param region2
	 * @param username
	 * @param pswd
	 */
	@RequestMapping(value = "/buttonStop/{regionName}/{selectedCheckBox}/{selectedOptions}/{region2}/{username}/{pswd}", method = RequestMethod.GET)
	public void logStopBoxes(
			@PathVariable("selectedCheckBox") String selectedCheckBox,
			@PathVariable("regionName") String regionName,
			@PathVariable("selectedOptions") String selectedOptions,

			@PathVariable("region2") String region2,
			@PathVariable("username") String username,
			@PathVariable("pswd") String pswd) {

		logger.info("Stop" + " " + selectedCheckBox + " " + regionName);
		logger.info(region2 + " " + selectedOptions + " " + username + " "
				+ pswd);

	}

	/**
	 * Desc: get details on clicking the restart button
	 * 
	 * @param selectedCheckBox
	 * @param regionName
	 * @param selectedOptions
	 * @param region2
	 * @param username
	 * @param pswd
	 * 
	 */
	@RequestMapping(value = "/buttonRestart/{regionName}/{selectedCheckBox}/{selectedOptions}/{region2}/{username}/{pswd}", method = RequestMethod.GET)
	public void logRestartBoxes(
			@PathVariable("selectedCheckBox") String selectedCheckBox,
			@PathVariable("regionName") String regionName,
			@PathVariable("selectedOptions") String selectedOptions,
			@PathVariable("region2") String region2,
			@PathVariable("username") String username,
			@PathVariable("pswd") String pswd) {

		logger.info("Restart" + " " + selectedCheckBox + " " + regionName);
		logger.info(region2 + " " + selectedOptions + " " + username + " "
				+ pswd);

	}
}
