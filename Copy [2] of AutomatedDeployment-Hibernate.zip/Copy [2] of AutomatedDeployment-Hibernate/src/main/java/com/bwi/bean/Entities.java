package com.bwi.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="deployment")
public class Entities implements Serializable {
	private static final long serialVersionUID = 1L;

	

	private String region;
	


	private int id;
	

	/**
	 * @return the entitlementId
	 */
	
	
	
	@Id
	@Column(name="region")
	public String getRegion() {
		return region;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	@Id
	@Column(name="id")
	public int getId()
	{
		return id;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	

}
