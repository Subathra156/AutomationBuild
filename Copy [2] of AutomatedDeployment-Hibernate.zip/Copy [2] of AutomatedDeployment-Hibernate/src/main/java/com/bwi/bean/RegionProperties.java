package com.bwi.bean;

public class RegionProperties {
	private String regionId,assemblyId,url,environment,siteminderAgentConfig;
	public String getRegionId() {
		return regionId;
	}
	public void setRegionId(String regionId) {
		this.regionId = regionId;
	}
	public String getAssemblyId() {
		return assemblyId;
	}
	public void setAssemblyId(String assemblyId) {
		this.assemblyId = assemblyId;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getEnvironment() {
		return environment;
	}
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	public String getSiteminderAgentConfig() {
		return siteminderAgentConfig;
	}
	public void setSiteminderAgentConfig(String siteminderAgentConfig) {
		this.siteminderAgentConfig = siteminderAgentConfig;
	}
	public static void main(String[] args) {
	


	}

}
