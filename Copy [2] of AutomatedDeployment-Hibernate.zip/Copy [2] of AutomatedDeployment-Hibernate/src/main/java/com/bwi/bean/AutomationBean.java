package com.bwi.bean;

/**
 * @author XBBNHD2
 * @since 08/17/2017 Description:Bean class to for getting and setting the
 *        regions
 *
 */
public class AutomationBean {
	private String region;

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

}
