/**
 * 
 */
package com.bwi.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;

import com.bwi.bean.AutomationBean;

/**
 * @author XBBNHD2 Description:Row mapper class to iterate through the resultset
 *         and retrieve the regions.
 * @since:08/17/2017
 */
public class RegionMapper implements RowMapper {

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		// List<String> regionList=new ArrayList<String>();
		AutomationBean automationBean = new AutomationBean();
		// regionList.add(rs.getString("REGION"));
		// System.out.println(regionList);
		automationBean.setRegion(rs.getString("REGION"));
		return automationBean;
	}
}