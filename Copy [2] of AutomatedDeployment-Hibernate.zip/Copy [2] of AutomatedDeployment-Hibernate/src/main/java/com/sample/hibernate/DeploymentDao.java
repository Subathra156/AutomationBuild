package com.sample.hibernate;

import java.util.List;

/**
 * @author XBBNHD2
 * @since 09/06/2017 Desc: interface for invoking methods in hibernate Dao
 */
public interface DeploymentDao {

	public Deployment get(Integer id);

	public List<Deployment> getAll();
}
