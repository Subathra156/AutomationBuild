package com.sample.hibernate;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;



/**
 * @author XBBNHD2
 * @since 09/06/2017 Desc: Implementation for the DAO class
 */
@Lazy
@Repository
@Transactional
@Component
public class DeploymentDaoImpl extends HibernateDao<Deployment, Integer>
		implements DeploymentDao {

	public DeploymentDaoImpl() {

	}
}
