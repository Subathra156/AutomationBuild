package com.sample.hibernate;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.exception.DataException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;


/**
 * @author XBBNHD2
 * @since 09/05/2017 Desc : Hibernate DAO class containing common methods
 * @param <T>
 * @param <ID>
 */
@Component
@Transactional
public abstract class HibernateDao<T, ID extends Serializable> {
	public static final String GET = "get";

	@Autowired
	private SessionFactory sessionFactory;

	private Class<T> entityClass;

	@SuppressWarnings("unchecked")
	protected HibernateDao() {
		this.entityClass = (Class<T>) ((ParameterizedType) getClass()
				.getGenericSuperclass()).getActualTypeArguments()[0];
	}

	protected HibernateDao(final Class<T> entityClass) {
		this.entityClass = entityClass;
	}

	@SuppressWarnings("unchecked")
	public T get(final ID id) throws DataException {
		try {
			Session session = sessionFactory.openSession();
			final T t = (T) session.get(this.entityClass, id);
			return t;
		} finally {
		}
	}

	@SuppressWarnings("unchecked")
	public List<T> getAll() throws DataException {
		try {
			Session session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(this.entityClass);

			final List<T> t = criteria.list();

			return t;
		} finally {
		}
	}
}
