package com.sample.hibernate;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * @author XBBNHD2
 * @since 09/07/2017 Desc: class for invoking the methods in DAO classes
 */
@Scope("prototype")
@Component
public class DeploymentHandle {

	@Autowired
	DeploymentDao dao;

	/**
	 * @return single row, corresponding to the id passed
	 */
	public Deployment get() {

		Deployment deployment = new Deployment();
		deployment.setId(2);
		Deployment deploymentFinal = dao.get(deployment.getId());
		return deploymentFinal;

	}

	/**
	 * 
	 * @return List of rows of from the table
	 */
	public List<Deployment> getAll() {

		List<Deployment> deploymentFinal = new ArrayList<Deployment>();
		deploymentFinal.addAll(dao.getAll());
		return deploymentFinal;

	}
}
