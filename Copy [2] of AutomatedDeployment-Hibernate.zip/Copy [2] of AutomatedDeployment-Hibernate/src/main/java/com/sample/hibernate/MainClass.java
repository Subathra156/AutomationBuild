package com.sample.hibernate;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

/**
 * @author XBBNHD2
 * @since 09/06/2017 Desc: Stand alone class for hibernate implementation
 */
@Component
public class MainClass {

	public static void main(String ars[]) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
				"dbConfig.xml");
		DeploymentHandle dh = ctx.getBean(DeploymentHandle.class);
		Deployment deploymentObj = dh.get();

		List<Deployment> deployment = new ArrayList<Deployment>();
		List<String> regionList = new ArrayList<String>();

		deployment.addAll(dh.getAll());
		Iterator itr = deployment.iterator();
		while (itr.hasNext()) {
			Deployment db = (Deployment) itr.next();
			regionList.add(db.getRegion());

		}

	}
}
