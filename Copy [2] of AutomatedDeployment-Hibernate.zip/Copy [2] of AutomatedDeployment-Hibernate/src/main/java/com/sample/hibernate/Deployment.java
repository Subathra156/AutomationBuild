package com.sample.hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @since 09/05/2017
 * @author XBBNHD2 
 * Desc Mapping for the rows in the Database
 *
 *
 */
@Entity
@Table(name = "deployment")
public class Deployment {

	private String region;

	@Id
	private Integer id;

	@Column(name = "region")
	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	@Column(name = "id")
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

}
